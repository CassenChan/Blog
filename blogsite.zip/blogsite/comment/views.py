from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.views.decorators.http import require_GET, require_POST
from . import models
import time


# Create your views here.
@require_GET
def showmessage_page(request):
  all_comment = []
  comments = models.Comment.objects.all()
  for comment in comments:
      info = "第" + str(comment.id) + "条评论" + "内容为：" + str(comment.content) + " 评论时间：" + str(comment.cdate)
      all_comment.append(info)
  return render(request, "showmessage_page.html", {"all_comment": all_comment})


@require_POST
def getmessage(request):
  content = request.POST.get("content")
  cdate = time.strftime('%Y-%m-%d' , time.localtime())
  if content != "":
      models.Comment.objects.create(content=content, cdate=cdate)
  return HttpResponseRedirect('/message/showmessage/')