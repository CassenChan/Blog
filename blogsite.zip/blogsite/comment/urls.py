from django.urls import path
from . import views

urlpatterns = [
    path('showmessage/', views.showmessage_page),
    path('getmessage/', views.getmessage),
]